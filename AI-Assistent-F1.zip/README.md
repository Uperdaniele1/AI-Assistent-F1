# AI Assistent F1

Race engineer personale per F1 e Le Mans Ultimate (LMU).

## Prima versione

Questa versione è un MVP funzionante che permette di:

- caricare un giro attuale in CSV;
- caricare un best lap di riferimento;
- calcolare il tempo del giro e il delta;
- analizzare velocità, frenata e acceleratore;
- generare feedback in stile race engineer;
- usare una dashboard web locale.

> Nota: i formati telemetrici specifici di F1 e LMU cambiano in base al gioco/versione/plugin. Il motore di importazione è volutamente generico e sarà esteso quando avremo un file telemetrico reale.

## Installazione

Richiede Python 3.11+.

```bash
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

macOS/Linux:
```bash
source .venv/bin/activate
```

Poi:

```bash
pip install -r requirements.txt
uvicorn backend.app.main:app --reload
```

Apri nel browser:

http://127.0.0.1:8000

## CSV minimo

Il CSV deve contenere almeno:

```text
time,speed,throttle,brake
0.000,120,0,0
0.020,118,0,30
0.040,115,0,80
...
```

Sono supportati anche alcuni alias comuni per i nomi delle colonne.

## Roadmap

1. Importazione reale F1/LMU.
2. Sincronizzazione dei giri sulla distanza.
3. Delta curva per curva.
4. Rilevamento automatico di frenata, apex e uscita curva.
5. Analisi ERS/batteria per F1.
6. Racing line ideale per LMU.
7. Grafici telemetrici interattivi.
8. Race engineer AI più avanzato.
