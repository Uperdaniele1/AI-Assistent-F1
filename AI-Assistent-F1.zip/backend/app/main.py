from __future__ import annotations

import io
from pathlib import Path

import pandas as pd
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from .telemetry import analyze_lap, normalize_telemetry

app = FastAPI(title="AI Assistent F1", version="0.1.0")

ROOT = Path(__file__).resolve().parents[2]
FRONTEND = ROOT / "frontend"

app.mount("/static", StaticFiles(directory=FRONTEND), name="static")


@app.get("/")
def home():
    return FileResponse(FRONTEND / "index.html")


@app.get("/api/health")
def health():
    return {"status": "ok", "project": "AI Assistent F1", "version": "0.1.0"}


@app.post("/api/analyze")
async def analyze(
    current: UploadFile = File(...),
    best: UploadFile | None = File(None),
):
    try:
        current_df = normalize_telemetry(
            pd.read_csv(io.BytesIO(await current.read()))
        )

        best_df = None
        if best is not None:
            best_df = normalize_telemetry(
                pd.read_csv(io.BytesIO(await best.read()))
            )

        result = analyze_lap(current_df, best_df)

        return {
            "lap_time": result.lap_time,
            "best_lap_time": result.best_lap_time,
            "delta": result.delta,
            "potential_gain": result.potential_gain,
            "suggestions": result.suggestions,
            "samples": len(current_df),
        }

    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
