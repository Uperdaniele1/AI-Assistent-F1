from __future__ import annotations

from dataclasses import dataclass
import pandas as pd


ALIASES = {
    "time": ["time", "timestamp", "elapsed", "elapsed_time", "session_time"],
    "speed": ["speed", "velocity", "kmh", "speed_kmh"],
    "throttle": ["throttle", "accelerator", "accel", "gas"],
    "brake": ["brake", "braking", "brake_pressure"],
    "gear": ["gear"],
    "distance": ["distance", "distance_m", "lap_distance"],
}


@dataclass
class LapAnalysis:
    lap_time: float
    best_lap_time: float | None
    delta: float | None
    potential_gain: float
    suggestions: list[str]


def _find_column(df: pd.DataFrame, aliases: list[str]) -> str | None:
    columns = {str(c).strip().lower(): c for c in df.columns}
    for alias in aliases:
        if alias in columns:
            return columns[alias]
    return None


def normalize_telemetry(df: pd.DataFrame) -> pd.DataFrame:
    out = pd.DataFrame(index=df.index)

    for target, aliases in ALIASES.items():
        source = _find_column(df, aliases)
        if source is not None:
            out[target] = pd.to_numeric(df[source], errors="coerce")

    required = ["time", "speed", "throttle", "brake"]
    missing = [name for name in required if name not in out.columns]
    if missing:
        raise ValueError("Colonne mancanti: " + ", ".join(missing))

    for optional in ("gear", "distance"):
        if optional not in out.columns:
            out[optional] = float("nan")

    out = out.dropna(subset=required).reset_index(drop=True)

    if len(out) < 5:
        raise ValueError("Servono almeno 5 campioni di telemetria.")

    return out


def lap_time(df: pd.DataFrame) -> float:
    return float(df["time"].iloc[-1] - df["time"].iloc[0])


def analyze_lap(current: pd.DataFrame, best: pd.DataFrame | None = None) -> LapAnalysis:
    current_time = lap_time(current)
    best_time = lap_time(best) if best is not None else None
    delta = current_time - best_time if best_time is not None else None

    suggestions: list[str] = []
    potential = 0.0

    speed = current["speed"].to_numpy()
    throttle = current["throttle"].to_numpy()
    brake = current["brake"].to_numpy()

    # Prima euristica: frenate forti.
    if len(speed) > 10:
        decel = speed[:-1] - speed[1:]
        threshold = max(3.0, float(decel.std()) * 1.5)
        hard_braking = decel > threshold

        if hard_braking.any():
            idx = int(hard_braking.argmax())
            if brake[idx] > 80:
                suggestions.append(
                    "Frenata molto aggressiva: prova un rilascio più progressivo "
                    "verso l'apice."
                )
                potential += 0.015

        # Prima euristica: uscita curva.
        full_throttle = throttle > 95
        if full_throttle.any():
            first_full = int(full_throttle.argmax())
            if first_full > 0 and brake[first_full - 1] > 5:
                suggestions.append(
                    "Controlla l'uscita di curva: anticipare l'acceleratore "
                    "può migliorare il tempo sul rettilineo."
                )
                potential += 0.020

    if delta is None:
        suggestions.insert(0, "Questo giro è il primo riferimento.")
    elif delta > 0:
        suggestions.insert(0, f"Sei {delta:.3f}s sopra il best lap.")
    else:
        suggestions.insert(
            0, f"Nuovo riferimento: {abs(delta):.3f}s più veloce del best lap."
        )

    if not suggestions:
        suggestions.append(
            "Telemetria acquisita. Servono più giri per un confronto dettagliato."
        )

    return LapAnalysis(
        lap_time=current_time,
        best_lap_time=best_time,
        delta=delta,
        potential_gain=potential,
        suggestions=suggestions,
    )
