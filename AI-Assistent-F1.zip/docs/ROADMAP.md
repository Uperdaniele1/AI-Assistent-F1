# Roadmap

## Fase 1 — MVP
- [x] Upload CSV
- [x] Analisi base
- [x] Delta best lap
- [x] Dashboard locale

## Fase 2 — Telemetria reale
- [ ] Identificare formato telemetria F1
- [ ] Identificare formato telemetria LMU
- [ ] Parser dedicati
- [ ] Normalizzazione sulla distanza

## Fase 3 — Analisi racing
- [ ] Segmentazione automatica curve
- [ ] Punto di frenata
- [ ] Trail braking
- [ ] Apex
- [ ] Throttle application
- [ ] Gear/speed comparison
- [ ] Ideal line

## Fase 4 — F1 Race Engineer
- [ ] ERS deployment
- [ ] Battery target
- [ ] Strategie giro per giro
- [ ] Feedback in tempo reale

## Fase 5 — AI
- [ ] Spiegazioni naturali
- [ ] Priorità delle perdite di tempo
- [ ] Coaching personalizzato
- [ ] Confronto tra sessioni
